# Angular2ImagePuzzle
A sample Image Puzzle game created using HTML 5 drag drop event 

## To run this application 
1. clone the repository to your local folder 
2. Run "npm install"
3. Run "npm start" 
